document.addEventListener('DOMContentLoaded', () => {
  console.log("Portofolio PWA Dimuat");
  // Tambahkan logika dinamis di sini
});
