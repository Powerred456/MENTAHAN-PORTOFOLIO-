console.log("Script portofolio dimuat.");
